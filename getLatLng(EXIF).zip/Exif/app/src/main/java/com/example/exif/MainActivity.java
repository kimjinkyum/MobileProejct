package com.example.exif;

import java.io.File;
import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

public class MainActivity extends Activity {

    private TextView mView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //읽기 권한 요청 - 이것 때문에 어플의 첫 실행 때는 위도경도 못 불러올 수 있음. 권한 얻은 2번째 실행부터 정상 가동
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        1);
            }
        }





        mView = (TextView) findViewById(R.id.textview);


        String filename = Environment.getExternalStorageDirectory()
                .getPath() + "/test.jpg";

        //File file = new File(Context.getFileStreamPath("/storage/emulated/0/test.jpg"));

        float[] latlng = new float[2];
        boolean isDone;
        try {
            ExifInterface exif = new ExifInterface(filename);

            isDone = exif.getLatLong(latlng);  // 성공적으로 읽을 시 true 리턴

            // latlng[0] : 위도
            // latlng[1] : 경도
            Log.d("latlng", latlng[0] + " " + latlng[1]);
            mView.setText(latlng[0] + " " + latlng[1]);
            // showExif(exif);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error!", Toast.LENGTH_LONG).show();
        }





        /*
    private void showExif(ExifInterface exif) {

        String myAttribute = "[Exif information] \n\n";

        myAttribute += getTagString(ExifInterface.TAG_DATETIME, exif);
        myAttribute += getTagString(ExifInterface.TAG_FLASH, exif);
        myAttribute += getTagString(ExifInterface.TAG_GPS_LATITUDE,
                exif);
        myAttribute += getTagString(
                ExifInterface.TAG_GPS_LATITUDE_REF, exif);
        myAttribute += getTagString(ExifInterface.TAG_GPS_LONGITUDE,
                exif);
        myAttribute += getTagString(
                ExifInterface.TAG_GPS_LONGITUDE_REF, exif);
        myAttribute += getTagString(ExifInterface.TAG_IMAGE_LENGTH,
                exif);
        myAttribute += getTagString(ExifInterface.TAG_IMAGE_WIDTH,
                exif);
        myAttribute += getTagString(ExifInterface.TAG_MAKE, exif);
        myAttribute += getTagString(ExifInterface.TAG_MODEL, exif);
        myAttribute += getTagString(ExifInterface.TAG_ORIENTATION,
                exif);
        myAttribute += getTagString(ExifInterface.TAG_WHITE_BALANCE,
                exif);

        mView.setText(myAttribute);
    }

    private String getTagString(String tag, ExifInterface exif) {
        return (tag + " : " + exif.getAttribute(tag) + "\n");
    }
    */




    }
}
