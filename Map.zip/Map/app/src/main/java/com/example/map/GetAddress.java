package com.example.map;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;


public class GetAddress extends Thread
{
    double m_dbLatitude, m_dbLongitude;
    MapsActivity.reverseGeoHandler reHan;

    public GetAddress( double dbLatitude, double dbLongitude,
                       MapsActivity.reverseGeoHandler ha)
    {
        m_dbLatitude = dbLatitude;
        m_dbLongitude = dbLongitude;
        reHan = ha;
    }



    @Override
    public void run()
    {
        super.run( );

        String strUrl = "https://maps.googleapis.com/maps/api/geocode/json?latlng="
                + m_dbLatitude + "," + m_dbLongitude
                + "&language=ko&region=KO,+CA&key=AIzaSyAIOKyyEy92A_eaxB4fBMEU6YwqtK-vYfU";
        HttpURLConnection clsConn = null;
        StringBuffer clsBuf = new StringBuffer();

        try
        {
            URL clsUrl = new URL( strUrl );
            clsConn = (HttpURLConnection)clsUrl.openConnection();

            BufferedReader in = new BufferedReader(new InputStreamReader(clsConn.getInputStream(), "UTF-8"));

            char [] arrBuf = new char[8192];
            int n;

            while( ( n = in.read( arrBuf ) ) > 0 )
            {
                clsBuf.append( arrBuf, 0, n );
            }

            in.close();

            JSONObject json = new JSONObject( clsBuf.toString( ) );

            JSONArray arrResults = json.getJSONArray( "results" );


            JSONObject clsItem = (JSONObject)arrResults.get(0);
            JSONArray arrAddress = clsItem.getJSONArray( "address_components" );
            JSONObject clsAddress = (JSONObject)arrAddress.get(3);
            Log.d( "address", clsAddress.getString( "long_name" ) );

            Bundle data = new Bundle();
            data.putString("city", clsAddress.getString( "long_name" ));
            Message msg = reHan.obtainMessage();
            msg.setData(data);
            reHan.sendMessage(msg);


            /*
            int iCount = arrResults.length( );
            for( int i = 0; i < iCount; ++i )
            {
                JSONObject clsItem = (JSONObject)arrResults.get( i );
                JSONArray arrAddress = clsItem.getJSONArray( "address_components" );


                int iAddressCount = arrAddress.length( );
                for( int j = 0; j < iAddressCount; ++j )
                {
                    JSONObject clsAddress = (JSONObject)arrAddress.get( j );

                    Log.d( "address", clsAddress.getString( "long_name" ) );
                    // Toast.makeText(this, clsAddress.getString( "long_name" ), Toast.LENGTH_LONG).show();
                }
            }
            */
        }
        catch( Exception e )
        {
            Log.e("ConnectionError", "Exception", e);
        }
        finally
        {
            if( clsConn != null ) clsConn.disconnect( );
        }
    }
}