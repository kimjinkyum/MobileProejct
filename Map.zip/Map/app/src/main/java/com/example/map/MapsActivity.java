package com.example.map;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;


    private int imageId;


    private View infoWindow;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);





        Toast.makeText(this, "Toast onCreate", Toast.LENGTH_LONG).show();



        GetAddress reverseGeo = new GetAddress(37, 127);
        reverseGeo.start();









        infoWindow=getLayoutInflater().inflate(R.layout.info, null);





        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {


        Toast.makeText(this, "Toast onMapReady1", Toast.LENGTH_LONG).show();


        mMap = googleMap;




        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-40, 160);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Sydney"));




        LatLng next = new LatLng(-33, 150);
        mMap.addMarker(new MarkerOptions().position(next).title("next"));



        mMap.setInfoWindowAdapter(new CustomInfoAdapter());




        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                if (marker.getTitle().compareTo("Sydney") == 0) {
                    imageId = 0;
                }

                else if (marker.getTitle().compareTo("next") == 0) {
                    imageId = 1;
                }




                return false;
            }
        });




        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));




        Toast.makeText(this, "Toast onMapReady2", Toast.LENGTH_LONG).show();




    }






    class CustomInfoAdapter implements GoogleMap.InfoWindowAdapter {


        @Override
        public View getInfoContents(Marker marker) {
            if (imageId == 0) {
                ((ImageView)infoWindow.findViewById(R.id.image)).setImageResource(R.drawable.arrow);

            }
            else if (imageId == 1) {
                ((ImageView)infoWindow.findViewById(R.id.image)).setImageResource(R.drawable.arrow2);
            }

            return infoWindow;
        }

        @Override
        public View getInfoWindow(Marker arg0) {

            return null;
        }


    }









}
